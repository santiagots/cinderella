﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ventas.Core.Enum
{
    public enum ReservaMetodoEntrega
    {
        Envió_A_Domicilio,
        Retira_Por_Sucursal,
        A_Convenir
    }
}
