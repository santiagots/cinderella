﻿
using Common.Core.Model;

namespace Common.Core.Interfaces
{
    public interface IClienteMayoristaRepository
    {
        ClienteMayorista Obtener(int id);
    }
}
