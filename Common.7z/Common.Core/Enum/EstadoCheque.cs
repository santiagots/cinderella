﻿namespace Common.Core.Enum
{
    public enum EstadoCheque
    {
        Ingresado,
        Salido,
        Reingresado
    }
}
