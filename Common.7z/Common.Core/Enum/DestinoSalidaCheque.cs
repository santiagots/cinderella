﻿namespace Common.Core.Enum
{
    public enum DestinoSalidaCheque
    {
        SinSalida,
        Depositado,
        Pasado,
        Devuelto,
        Otro
    }
}