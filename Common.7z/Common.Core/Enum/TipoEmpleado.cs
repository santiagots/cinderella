﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Core.Enum
{
    public enum TipoEmpleado
    {
        Vendedor = 1,
        Encargado = 2,
        Supervisor = 3
    }
}
