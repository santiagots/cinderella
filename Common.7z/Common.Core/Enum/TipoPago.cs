﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common.Core.Enum
{
    public enum TipoPago
    {
        Efectivo = 1,
        TarjetaCredito = 2,
        TarjetaDebito = 3,
        Cheque = 4,
        Deposito = 5,
        Bonificacion = 6
    }
}
