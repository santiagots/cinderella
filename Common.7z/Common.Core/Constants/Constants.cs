﻿namespace Common.Core.Constants
{
    public static class Constants
    {
        public const decimal IVA = 0.21M;
    }
}
